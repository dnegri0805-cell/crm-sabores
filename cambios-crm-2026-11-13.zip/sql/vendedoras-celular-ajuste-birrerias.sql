-- Cambios del 13/11/2026 (ya aplicados en Supabase; este archivo queda como registro)

-- 1) Cada perfil tiene su celular (sale en los folletos que comparte) y, para las vendedoras,
--    un ajuste de precio en % que se suma a la lista cuando cargan pedidos.
alter table public.perfiles add column if not exists celular text;
alter table public.perfiles add column if not exists ajuste_precio_pct numeric not null default 0;
-- Jessi y Tatiana: comisión 5 % y ajuste de 5,26 % (precio ÷ 0,95, para que la comisión no baje el margen).

-- 2) Maní a granel para birrerías y cervecerías (JL SA).
--    OJO: en el CRM los costos y precios van CON IVA. costo_usd = USD por kilo + IVA (1,7 × 1,21 y 2,2 × 1,21).
--    costo = costo_usd × dólar; precio fijo = costo ÷ 0,65.
-- Productos: MJL-FRITO-20KG (caja 20 kg) y MJL-CROC-15KG (caja 15 kg), por peso, se venden por caja entera.

-- 3) Cuando se cambia el dólar (config_app.clave = 'dolar'), se recalculan solos el costo y el precio fijo de esos dos productos.
create or replace function public.recalcular_mani_granel_por_dolar()
returns trigger language plpgsql security definer set search_path = public as $$
declare d numeric;
begin
  if new.clave = 'dolar' then
    begin d := new.valor::numeric; exception when others then return new; end;
    if d is not null and d > 0 then
      update public.productos
         set costo = round(costo_usd * d, 2),
             precio_fijo = round(costo_usd * d / 0.65, 2)
       where codigo in ('MJL-FRITO-20KG', 'MJL-CROC-15KG') and costo_usd is not null;
    end if;
  end if;
  return new;
end; $$;
drop trigger if exists trg_recalcular_mani_granel_por_dolar on public.config_app;
create trigger trg_recalcular_mani_granel_por_dolar
after insert or update of valor on public.config_app
for each row execute function public.recalcular_mani_granel_por_dolar();
